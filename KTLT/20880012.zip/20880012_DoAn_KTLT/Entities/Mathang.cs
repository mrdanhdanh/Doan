﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace _20880012_DoAn_KTLT.Entities
{
    public class Mathang
    {
        public string MaMatHang;
        public string TenMatHang;
        public string CongTySanXuat;
        public string LoaiHang;
        public int Gia;
        public string NgaySanXuat;
        public string HanSuDung;
    }
}
