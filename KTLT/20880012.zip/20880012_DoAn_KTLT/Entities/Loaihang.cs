﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace _20880012_DoAn_KTLT.Entities
{
    public struct Loaihang
    {
        public string MaLoaiHang;
        public string TenLoaiHang;
    }
}
