﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace _20880012_DoAn_KTLT.Entities
{
    public class TonkhoMH
    {
        public string MaMH;
        public int SL;
    }
    public class TonkhoLH
    {
        public string TenLH;
        public int SL;
    }

}
