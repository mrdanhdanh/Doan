﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace _20880012_DoAn_KTLT.Entities
{
    public class HDxuat
    {
        public string MaHD;
        public string NgayXuat;
        public List<PhieuHH> DSBanHang;
        public int ThanhTien;
    }
}
